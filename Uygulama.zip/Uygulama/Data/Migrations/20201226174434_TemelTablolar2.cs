﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Uygulama.Data.Migrations
{
    public partial class TemelTablolar2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
