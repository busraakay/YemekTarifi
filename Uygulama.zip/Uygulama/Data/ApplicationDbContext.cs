﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Uygulama.Models;

namespace Uygulama.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Yemek> Yemek { get; set; }

        public DbSet<Kategori> Kategori { get; set; }

        public DbSet<Malzeme> Malzeme { get; set; }
    }
}
