﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Uygulama.Models
{
    public class Malzeme
    {
        public int MalzemeId { get; set; }

        public string MalzemeAdi { get; set; }

    }
}
