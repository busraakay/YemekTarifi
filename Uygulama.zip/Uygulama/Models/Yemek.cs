﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Uygulama.Models
{
    public class Yemek
    {
        public int Id { get; set; }

        public string Adi { get; set; }

        public bool? Favori { get; set; }

        public string Tarif { get; set; }

        public string Resim { get; set; }

        public int? HazirlikSuresi { get; set; }

        public int? PisirmeSuresi { get; set; }

        [DataType(DataType.Date)]
        public DateTime YuklemeTarihi { get; set; }

        public int KategoriId { get; set; }
        public Kategori Kategori { get; set; }

    



    }
}           
