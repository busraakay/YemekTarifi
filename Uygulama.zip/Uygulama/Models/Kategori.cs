﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Uygulama.Models
{
    public class Kategori
    {
        public int KategoriId { get; set; }

        public string KategoriAdi { get; set; }

        //public ICollection<Yemek> Yemek{ get; set; }
    }
}
